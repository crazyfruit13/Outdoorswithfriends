<?php

do_action('wanderland_mikado_action_style_dynamic');