<?php

include_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/author-info/functions.php';
require_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/author-info/author-info.php';