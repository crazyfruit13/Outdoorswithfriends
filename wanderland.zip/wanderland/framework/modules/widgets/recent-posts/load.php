<?php

include_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/recent-posts/functions.php';
include_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/recent-posts/recent-posts.php';
