<?php

include_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/button-widget/functions.php';
include_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/widgets/button-widget/button.php';