<div class="mkdf-skewed-section-effect <?php echo esc_attr( $additional_class ) ?>" <?php wanderland_mikado_inline_style( $skewed_section_effect_style ) ?>>
	<?php echo wanderland_mikado_get_module_part( $skewed_section_svg ); ?>
</div>