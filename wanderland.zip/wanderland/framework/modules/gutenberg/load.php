<?php
if ( wanderland_mikado_is_plugin_installed( 'gutenberg-editor' ) || wanderland_mikado_is_plugin_installed( 'gutenberg-plugin' ) ) {
	include_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/gutenberg/functions.php';
}
