<?php

if ( wanderland_mikado_is_plugin_installed( 'visual-composer' ) ) {
	include_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/visualcomposer/visual-composer-config.php';
}