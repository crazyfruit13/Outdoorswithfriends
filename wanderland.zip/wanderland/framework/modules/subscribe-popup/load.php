<?php

include_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/subscribe-popup/functions.php';

//load global subscribe popup options
include_once WANDERLAND_MIKADO_FRAMEWORK_MODULES_ROOT_DIR . '/subscribe-popup/options-map/subscribe-popup-map.php';
