<?php
if(wanderland_mikado_show_comments()){
    comments_template('', true);
}