<div class="mkdf-post-info-category-simple">
	<?php echo wanderland_mikado_icon_collections()->renderIcon( 'icon_tag_alt', 'font_elegant' ); ?>
	<?php the_category(', '); ?>
</div>