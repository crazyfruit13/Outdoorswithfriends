<div class="mkdf-post-info-category mkdf-st-highlight">
    <?php the_category(', '); ?>
    <span class="mkdf-st-highlight">
    <?php echo wanderland_section_title_highlighted_word_left_svg() ?>
    <span class="mkdf-active-hover-middle"></span>
    <?php echo wanderland_section_title_highlighted_word_right_svg() ?>
    </span>
</div>