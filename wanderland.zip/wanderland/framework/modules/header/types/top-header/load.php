<?php

include_once WANDERLAND_MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/top-header/functions.php';