<?php

include_once WANDERLAND_MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-bottom-minimal/functions.php';
include_once WANDERLAND_MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-bottom-minimal/header-bottom-minimal.php';