<?php

include_once WANDERLAND_MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-vertical/functions.php';
include_once WANDERLAND_MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-vertical/header-vertical.php';