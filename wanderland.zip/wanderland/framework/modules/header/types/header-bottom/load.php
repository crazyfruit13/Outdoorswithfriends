<?php

include_once WANDERLAND_MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-bottom/functions.php';
include_once WANDERLAND_MIKADO_FRAMEWORK_HEADER_ROOT_DIR . '/types/header-bottom/header-bottom.php';